const express = require("express");
const http = require("http");
const mongoose = require("mongoose");
const app = express();
const bodyParser = require('body-parser');
const Users = require('./model/user_model');
const usersRoutes = require('./routes/users');

app.use(express.json());
app.use(bodyParser.json());

//import routes
const usersRoute = require('./controllers/users.controllers'); 
app.use('/',usersRoute);


//http server connection
var server = http.createServer(app);
mongoose.connect("mongodb://localhost:27017/Assignment8DB");
mongoose.connection.on('connected', () => {
    console.log("Connected to Mongoose");
});
mongoose.connection.on('error', () => {
    console.log("Error connecting to Mongoose");
});

//accept node express 
app.get('/', (req,res) =>{
    res.send('Hello from Homepage');
});


server.listen(5001, () => {
    console.log("Server is running");
});


