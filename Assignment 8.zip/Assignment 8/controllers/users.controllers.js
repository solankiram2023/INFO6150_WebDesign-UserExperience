var express = require("express");
const User = require("../model/user_model");
const usersRoutes = require('../routes/users');
const validator  = require("validator");
const bcrypt = require("bcrypt");
const cors = require("cors");
var app=express.Router();

const success = "User created successfully";

const failure = "User creation failure due to ";

const notFound = "User not found";
 app.use(cors());

//Create new User
app.post("/users/create", async(req, res) => {
    try{
       const user = new User(req.body);
       const createUser = await user.save();
       res.status(201).send({ 
        message : "User Created Successfully."
       })
    }
    catch(e) {
        console.error(e);
        res.status(400).send({
        message : "User Creation failed."
       });
    }
})

// create new post request to authenticate user
app.post("/users/authenticate", cors(), async(req, res) => {
    try{
       //const user = new User(req.body);
       const {email,password} = req.body;
       console.log(email,password);
       let user = await User.findOne({ email: email });
       if(!user){
        res.send({authenticated: false});
        
       }
       else{
            const pass = await user.isValidPassword(password);
            if(pass) {
                res.send({authenticated:true});
            }
            else{
                res.send({authenticated:false});
            }
       }
    }catch(e) {
        console.error(e);
        res.status(400).send({
        message : "User not found."
       });
    }

})

//Update User
app.put('/users/edit/:email', async (req, res) => {
    try {
        //const { email } = req.params;
  
        // Check if the email field is available
        if (!req.body || req.body.email) {
            return res.status(400).send({
                "message" : "Email cannot be updated."
               });
        }
  
        let user = await User.findOne({ email: req.params.email });
  
        if (!user) {
            return res.status(404).send({
                message : "User not found"
               });
        }
  
        // Check if the password is being updated
        if (req.body.password) {
            // Hash the new password
            const salt = await bcrypt.genSalt(10);
            const hash = await bcrypt.hash(req.body.password, salt);
            req.body.password = hash;
        }
  
        // Apply the updates to the user object
        user = await User.findOneAndUpdate({ email: req.params.email }, req.body, {
            new: true,
            runValidators: true // This will ensure your schema's validations are checked
        });
        user.save();

        res.status(201).send({ 
            message : "User Updated Successfully."
           });
    } catch (e) {
        res.status(500).send({ 
            message : "User not updated."
           });
    }
  });
  

//Get all Users
app.get("/users/getAll", async(req,res) => {
    try{
        const userData = await User.find();
        res.send(userData);  
    }
    catch(e) {
        res.status(400).send({
            message : "User Data not found."
        });
    }
})

/delete User
app.delete("/users/delete/:email", async(req,res) => {
    try{
        const deleteUser = await User.findOneAndDelete(req.params.email);

        if(!req.params.id){
            return res.status(400).send({
                message : "User Deleted successfully."
            })
            //res.send(deleteUser);
        }
    }catch(e){
        res.status(500).send({
            message : "User Data not found."
        });
    }
})

module.exports = app;

