const express = require("express");
const router = express.Router();
const User = require("../model/user_model");
const userController = require('../controllers/users.controllers');
const bcrypt = require("bcrypt");

router.get('/', (req, res) => {
    res.send('Hello');
});

module.exports = router;