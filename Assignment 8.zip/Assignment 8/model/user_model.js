const mongoose = require("mongoose");
const validator  = require("validator");
const bcrypt = require("bcrypt");

const userSchema = new mongoose.Schema({
    fullname:{
        type: String,
        required: true,
        minlength: 3,
        validate:[
            {
                validator: (value) =>{
                 const length = value.length;
                 return length <20 && length>3;
                },
                message: "Full Name should be between 3 to 20 Characters",
            },
            {
                validator: (value) =>{
                return /^[a-zA-Z\s]*$/.test(value);
                },
                message: "Full Name should accept only characters.",
            },
        ]
    },
    email:{
        type: String,
        required: true,
        unique: true,
        validate:[
            {
                validator: (value) =>{
                return /^[a-z0-9._%+-]+@northeastern.edu$/.test(value);
                },
                message: "Only Northeastern Email id is valid",
            },
        ]
    },
    password:{
        type: String,
        required: true,
        validate:[
            {
                validator: (value) => {
                  return value.length < 20 && value.length > 8;
                },
                message: "Password length must be between 8 and 20 chracters",
              },
              {
                validator: (value) => {
                  return /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(value);
                },
                message: "Password should have atleast one lowercase alphabet, one uppercase alphabet, one digit and one special character.",
              },
        ]
    }
});

userSchema.pre("save", function (next) {
    const user = this;
    if (!user.isModified("password")) {
      return next();
    }
    bcrypt.genSalt(10, (err, salt) => {
      if (err) {
        return next(err);
      }
      bcrypt.hash(user.password, salt, (err, hash) => {
        if (err) {
          return next(err);
        }
        user.password = hash;
        next();
      });
    });
  });
  
//Check while sign up
userSchema.methods.isValidPassword = async function(password){
  return await bcrypt.compare(password, this.password);
};

var Users = new mongoose.model('User', userSchema);
module.exports = Users;
