INFO 6150 WEB DESIGN AND USER EXPIRENCE ENGINEERING ASSIGNMENT 1 

WEBSITE NAME : The Solanki Sports Academy.
DESCRIPTION: The Solanki Sports Academy is a website for an academy made with HTML and CSS.
             The website include various information about the Academy, photos, videos, audio and registration from.

STRUCTURE OF FILE:
                 -img ( all images used in  the website are in this folder)
                 -audios(audios used in the website are in this folder)
                 -videos(videos used in the website are in this folder)
                  CSS
                 -#style.css( This file contains styling of page)
                  HTML
                 -index.html(This webpage is home page of the website.)
                 -about.html(This webpage gives information about the academy with some videos.)
                 -gallery.html(This webpage shows photos of the academy events.)
                 -registration.html(This webpage has a registration form in it.)
                 -favicon.ico.png(This is the favicon of the website)
                 -logo.png(This is logo of th website)

HTML tags used in th website

1.Favicon - A favicon is a small image displayed next to the page title in the browser tab. 

2.Table - It allows to arrange data in rows and column.

3.Form - Form is a document that stores information of a user on a web server using interactive controls

4.Images - It is used to inster images in HTML page.

5.Hyperlinks-It is used to link from one page to another.

6.Button tag- The button tag defines a clickable button. It is used to trigger action on clicking button.

7.Audios tag-The audio tag is an inline element that is used to embed sound files into a web page.

8.video tag-The video tag is used to embed video content in a document, such as a movie clip or other video streams.

9.<header>- This tag defines a header for a document.

10.<footer>-This tag defines a footer for a document.

11.<summary>-The  <summary> tag is used with <details> tag. It is used as a summary, caption or legend for the content of a <details> element.

12.<menu>-The <menu> tag defines a list of commands. 

13.telphone-To create a link to a telephone number.

14.<mailto>-To create a link to a telephone number.

15.<main> : This tag is used here to specify the main content of a document.
                 
