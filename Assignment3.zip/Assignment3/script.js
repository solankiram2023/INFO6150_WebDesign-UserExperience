var rows = 3;
var checkedRows = 0;

tableHeader = [' ', 'STUDENT', 'ADVISOR', 'AWARD STATUS', 'SEMESTER', 'TYPE', 'BUDGET', 'PERCENTAGE', 'DELETE', 'EDIT'];
tableValues = [' ', 'Student ', 'Teacher ', 'Approved', 'Fall', 'TA', '23456', '100%', '<button onclick="delStudent(this)" class = "buttonDelete">Delete</button>', '<button onclick="editStudent(this)" class = "buttonEdit" >Edit</button>']

/* Code for Add New Row */

function addStudent() {

  let table = document.getElementById('myTable');
  let RowCount = table.rows.length;
  let RowId = rows + 1;

  alert("Student" + RowId + " Record added successfully");
  let trow = table.insertRow(RowCount);
  trow.setAttribute("id", RowId);

  const tableArr = [];
  for (let i = 0; i < tableHeader.length; i++) {
    tableArr.push(trow.insertCell(i));
  }

  rows += 1;
  tableArr[0].innerHTML = '<input type="checkbox"  onchange="clickCheckbox(this, true)" /><br /><br /><img src="down.png" width="25px" onclick="clickDropdown(this, true)"/>'
  tableArr[1].innerHTML = tableValues[1] + (rows);
  tableArr[2].innerHTML = tableValues[2] + (rows);
  tableArr[3].innerHTML = tableValues[3];
  tableArr[4].innerHTML = tableValues[4];
  tableArr[5].innerHTML = tableValues[5];
  tableArr[6].innerHTML = tableValues[6];
  tableArr[7].innerHTML = tableValues[7];
  tableArr[8].innerHTML = tableValues[8];
  tableArr[8].className = "deleteButton";
  tableArr[9].innerHTML = tableValues[9];
  tableArr[9].className = "editButton";

  var nxtrow = table.insertRow(RowCount + 1);
  nxtrow.className = "dropDownTextArea";
  var cell = nxtrow.insertCell(0);
  cell.innerHTML = '<td >Advisor:<br /><br />Award Details<br />Summer 1-2014(TA)<br />Budget Number: <br />Tuition Number: <br />Comments:<br /><br /><br />Award Status:<br /><br /><br /></td>';
  cell.colSpan = 8
}


/* Code for Edit Student */

function editStudent(val) {

   var RowId = val.parentNode.parentNode.id;
   var Row = document.getElementById(RowId);
   var Column = Row.getElementsByTagName("td");

   var data = [];
   for (var i = 0; i < Column.length; i++) {
       data.push(Column[i].innerHTML);
   }

   var Student = "";
   var Advisor = "";
   var AwardStatus = "";
   var Semester = "";
   var Type = "";
   var Budget = "";
   var Percentage = "";

   for(var i = 0; i < data.length; i++){
     fieldValue = data[i]
     switch(i) {
       case 1:
         Student = fieldValue
         break;
       case 2:
         Advisor = fieldValue
         break;
       case 3:
         AwardStatus = fieldValue
        break;
       case 4:
         Semester = fieldValue
         break;
       case 5:
         Type = fieldValue
         break;
       case 6:
         Budget = fieldValue
         break;
       case 7:
         Percentage = fieldValue
         break;
     }
   }  

  var rowData = 
   'Student: ' + Student +
   '\n | Advisor: ' + Advisor +
   '\n | Award Status: ' + AwardStatus +
   '\n | Semester: ' + Semester +
   '\n | Type: ' + Type +
   '\n | Budget#: ' + Budget +
  '\n | Percentage: ' + Percentage;

  let editPopup = prompt("Edit the details of Student " + RowId +'\n' +
  '\n   Student: ' + Student +
  '\n   Advisor: ' + Advisor +
  '\n   Award Status: ' + AwardStatus +
  '\n   Semester: ' + Semester +
  '\n   Type: ' + Type +
  '\n   Budget#: ' + Budget +
  '\n   Percentage: ' + Percentage, rowData);

  if (editPopup == null || editPopup == "") {
    alert("Student " + RowId + " data not updated successfully");
  } 
  else {
    alert("Student " + RowId + " data updated successfully");
  }
}


/* Code for Checkbox Click*/

function clickCheckbox(val, isDynamic) {
  let Row = val.parentNode.parentNode;

  if(isDynamic){
    var valEdit = Row.lastChild.lastChild;
    var valDelete = Row.lastChild.previousSibling.lastChild;
  } 
  else {
    var valEdit = Row.lastChild.previousSibling.lastChild;
    var valDelete = Row.lastChild.previousSibling.previousSibling.previousSibling.lastChild;
  }
  
  if (val.checked) {
    Row.style.backgroundColor = 'yellow';
    let x = document.getElementsByClassName("deleteButton");
    let y = document.getElementsByClassName("editButton");

    for (let i = 0; i < x.length; i++) {
      x[i].style.display = "table-cell";
      y[i].style.display = "table-cell";
    }

    valEdit.style.display = "block";
    valDelete.style.display = "block";
    checkedRows++;
  }

  else {
    Row.style.backgroundColor = 'transparent';
    let x = document.getElementsByClassName("deleteButton");
    let y = document.getElementsByClassName("editButton");
    valEdit.style.display = "none";
    valDelete.style.display = "none";
    checkedRows--;

    if (checkedRows == 0) {
      for (let i = 0; i < x.length; i++) {
        x[i].style.display = "none";
        y[i].style.display = "none";
      }
    }
  }

  if (checkedRows > 0) {
    let z = document.getElementById("button");
    z.disabled = false;
    z.style.backgroundColor = "orange";
  } 
  else if (checkedRows == 0) {
    let z = document.getElementById("button");
    z.disabled = true;
    z.style.backgroundColor = "grey";
  }

}


/* Code for Dropdown Click */

function clickDropdown(val, isDynamic) {

  if(isDynamic){
    var textRow = val.parentNode.parentNode.nextSibling;
  } 
  else {
    var textRow = val.parentNode.parentNode.nextSibling.nextSibling;
  }

  if (textRow.style.display == "table-row") {
    textRow.style.display = "none";
  } 
  else {
    textRow.style.display = "table-row";
  }
  
}

/* Code for Delete Student*/
function delStudent(val) {

  let Row = val.parentNode.parentNode.rowIndex;
  var RowId = val.parentNode.parentNode.id;
  alert("Student " + RowId + " Record deleted successfully");
  let table = document.getElementById('myTable');
  table.deleteRow(Row + 1);
  table.deleteRow(Row);

  checkedRows--;

  if (checkedRows > 0) {
    let z = document.getElementById("button");
    z.disabled = false;
    z.style.backgroundColor = "orange";
  } 
  else if (checkedRows == 0) {
    let z = document.getElementById("button");
    z.disabled = true;
    z.style.backgroundColor = "gray";
  }

  let x = document.getElementsByClassName("deleteButton");
  let y = document.getElementsByClassName("editButton");
  if (checkedRows == 0) {
    for (let i = 0; i < x.length; i++) {
      x[i].style.display = "none";
      y[i].style.display = "none";
    }
  }

}

