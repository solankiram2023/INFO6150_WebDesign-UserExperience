const { UserInputError } = require("../errors/errors")

testRegex = (pattern, str) => {
    return pattern.test(str)
}

isValidName = (name) => {
    // return testRegex(/^([a-zA-Z]{2,}\s[a-zA-Z]{1,}'?-?[a-zA-Z]{2,}\s?([a-zA-Z]{1,})?)/, name)
    return testRegex(/^([A-Za-z]+(?: [A-Za-z]+)*)$/, name)
}

isValidPassword = (password) => {
    return testRegex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9])(?=.{8,})/, password)
}

isValidEmail = (email) => {
    return testRegex(/^[A-Za-z0-9._%+-]+@northeastern\.edu$/, email)
}

validateEmailField = (email) => {
    if (email == null) {
        throw new UserInputError("Email required")
    }
    if (email.length > 60) {
        throw new UserInputError("Email cannot be more than 60 characters.")
    }
    if (!isValidEmail(email)) {
        throw new UserInputError("Email validation failed. Please enter email addresses with the domain '@northeastern.edu.'")
    }
}

validateNameField = (name) => {
    if (name == null) {
        throw new UserInputError("Name required")
    }
    if (name.length > 60) {
        throw new UserInputError("Name cannot be more than 60 characters.")
    }
    if (!isValidName(name)) {
        throw new UserInputError("Name validation failed. Name can only contain uppercase, lowercase letters and spaces.")
    }
}

validatePasswordField = (password) => {
    if (password == null) {
        throw new UserInputError("Password required")
    }
    if (password.length > 60) {
        throw new UserInputError("Password cannot be more than 60 characters.")
    }
    if (!isValidPassword(password)) {
        throw new UserInputError("Password validation failed. Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character.")
    }
}

validateUserFields = (email, name, password) => {
    validateEmailField(email)
    validateNameField(name)
    validatePasswordField(password)
}


module.exports = {
    validateEmailField,
    validateNameField, 
    validatePasswordField,
    validateUserFields
}
