# INFO6150_Keshava_Ketan_002685540
INFO6150 12891 Web Design/User Experien Engr SEC 01 - Fall 2023 [BOS-2-TR]

# Assignment 8

## Description
This project is a simple Node.js application that serves as a user management system with CRUD (Create, Read, Update, Delete) operations. The application uses Express for the server, MongoDB for the database, and Mongoose as the ODM (Object Data Modeling). The code is organized into various modules, including routes, services, models, repositories, mappers, and validators.

## Endpoints

### GET http://localhost:3000/user/getAll
- Retrieves a list of all users.
- Returns JSON containing user information.

### POST http://localhost:3000/user/create
- Creates a new user.
- Requires a JSON payload in the request body with the user's name, email, and password.
- Returns JSON containing the created user's information.

Example:
```json
{
    "name": "Full Name",
    "email": "name@northeastern.edu",
    "password": "Password@123"
}
```

### PUT http://localhost:3000/user/edit?email=name@northeastern.edu
- Updates an existing user by email.
- Requires a JSON payload in the request body with optional fields for updating the user's name and password.
- Returns JSON containing the updated user's information.

Example:
```json
{
    "name": "New Name",
    "password": "NewPassword@123"
}
```

### DELETE http://localhost:3000/user/delete?email=name@northeastern.edu
- Deletes an existing user by email.

### .env File
The application uses a `.env` file to store the MongoDB connection URL. The `.env` file should contain the following key-value pair:
```
DATABASE_URL=mongodb://localhost/user
```

### Error Handling
The project includes custom error classes in the `errors` folder, such as `UserDoesNotExist`, `UserInputError`, and `UserAlreadyExists`. These errors are thrown in case of specific situations, providing better clarity in error handling.

### Validators
Validators in the `validators` folder ensure that input fields meet specific criteria. They are used to validate email, name, and password fields before processing requests.

### Services
The `services` folder contains business logic for user-related operations, such as hashing passwords, retrieving users, creating users, updating users, and deleting users.

### Repositories
The `repositories` folder handles interactions with the database, including finding users by email, deleting users by email, fetching all users, and saving or updating user information.

### Models
The `models` folder defines the Mongoose schema for the `User` model, including fields for name, email, and password.

### Mappers
The `mappers` folder contains a mapping function to convert user objects to a format suitable for database operations.

### Additional Notes
- The application uses Express middleware to parse JSON in the request body (`app.use(express.json())`).
- The server is set to listen on port 3000 (`app.listen(3000, () => console.log('Server Started'))`).

## Getting Started
1. Clone the repository.
2. Create a `.env` file with the MongoDB connection URL.
3. Run `npm install` to install dependencies.
4. Start the server using `npm run devStart`.
